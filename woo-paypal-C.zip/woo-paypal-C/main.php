<?php
/**
 * Plugin Name: Enhanced Cart Redirector
 * Description: Redirects users to external checkout with complete cart data
 * Version: 2.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class CartRedirector {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('template_redirect', array($this, 'intercept_checkout'));
    }
    
    public function init() {
        // Plugin initialization
    }
    
    public function admin_menu() {
        add_options_page(
            'Cart Redirector Settings',
            'Cart Redirector',
            'manage_options',
            'cart-redirector',
            array($this, 'admin_page')
        );
    }
    
    public function admin_page() {
        if (isset($_POST['submit'])) {
            update_option('cart_redirector_url', sanitize_url($_POST['redirect_url']));
            echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
        }
        
        $redirect_url = get_option('cart_redirector_url', '');
        
        ?>
        <div class="wrap">
            <h1>Cart Redirector Settings</h1>
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th scope="row">Redirect URL</th>
                        <td>
                            <input type="url" name="redirect_url" value="<?php echo esc_attr($redirect_url); ?>" class="regular-text" required />
                            <p class="description">Enter the URL where users will be redirected (Plugin A website)</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    public function intercept_checkout() {
        if (is_checkout() && !is_admin()) {
            $redirect_url = get_option('cart_redirector_url');
            
            if (empty($redirect_url)) {
                return; // No redirect URL set
            }
            
            // Get cart data
            $cart_data = $this->get_cart_data();
            $user_data = $this->get_user_data();
            
            // Create form and auto-submit
            $this->create_redirect_form($redirect_url, $cart_data, $user_data);
            exit;
        }
    }
    
    private function get_cart_data() {
        $cart_data = array();
        
        if (WC()->cart && !WC()->cart->is_empty()) {
            foreach (WC()->cart->get_cart() as $cart_item) {
                $product = $cart_item['data'];
                $product_id = $cart_item['product_id'];
                $variation_id = $cart_item['variation_id'];
                
                // Get product image
                $image_id = $product->get_image_id();
                if (!$image_id && $variation_id) {
                    // Try to get variation image
                    $variation = wc_get_product($variation_id);
                    if ($variation) {
                        $image_id = $variation->get_image_id();
                    }
                }
                
                $image_url = '';
                if ($image_id) {
                    $image_url = wp_get_attachment_image_url($image_id, 'woocommerce_thumbnail');
                }
                
                // Get product data
                $item_data = array(
                    'product_id' => $product_id,
                    'variation_id' => $variation_id,
                    'quantity' => $cart_item['quantity'],
                    'name' => $product->get_name(),
                    'price' => $product->get_price(),
                    'regular_price' => $product->get_regular_price(),
                    'sale_price' => $product->get_sale_price(),
                    'image_url' => $image_url,
                    'sku' => $product->get_sku(),
                    'description' => $product->get_short_description(),
                    'weight' => $product->get_weight(),
                    'dimensions' => array(
                        'length' => $product->get_length(),
                        'width' => $product->get_width(),
                        'height' => $product->get_height()
                    )
                );
                
                // Add variation data if exists
                if ($variation_id && $variation_id > 0) {
                    $variation = wc_get_product($variation_id);
                    if ($variation) {
                        $item_data['variation_data'] = array(
                            'attributes' => $variation->get_variation_attributes(),
                            'variation_description' => $variation->get_description()
                        );
                    }
                }
                
                // Add any custom product meta
                $item_data['meta_data'] = array();
                foreach ($cart_item as $key => $value) {
                    if (strpos($key, '_') !== 0 && !in_array($key, array('key', 'product_id', 'variation_id', 'quantity', 'data', 'data_hash'))) {
                        $item_data['meta_data'][$key] = $value;
                    }
                }
                
                $cart_data[] = $item_data;
            }
        }
        
        return json_encode($cart_data);
    }
    
    private function get_user_data() {
        $user_data = array();
        
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            
            // Get billing and shipping info from user meta
            $billing_data = array();
            $shipping_data = array();
            
            $billing_fields = array(
                'first_name', 'last_name', 'company', 'address_1', 'address_2',
                'city', 'postcode', 'country', 'state', 'email', 'phone'
            );
            
            foreach ($billing_fields as $field) {
                $meta_key = 'billing_' . $field;
                $value = get_user_meta($user->ID, $meta_key, true);
                if (!empty($value)) {
                    $billing_data[$meta_key] = $value;
                }
            }
            
            // Use user's basic info if billing info is not available
            if (empty($billing_data['billing_first_name'])) {
                $billing_data['billing_first_name'] = $user->first_name;
            }
            if (empty($billing_data['billing_last_name'])) {
                $billing_data['billing_last_name'] = $user->last_name;
            }
            if (empty($billing_data['billing_email'])) {
                $billing_data['billing_email'] = $user->user_email;
            }
            
            // Get shipping data
            foreach ($billing_fields as $field) {
                if ($field === 'email' || $field === 'phone') continue; // Skip email/phone for shipping
                
                $meta_key = 'shipping_' . $field;
                $value = get_user_meta($user->ID, $meta_key, true);
                if (!empty($value)) {
                    $shipping_data[$meta_key] = $value;
                }
            }
            
            $user_data = array_merge($billing_data, $shipping_data);
            $user_data['user_id'] = $user->ID;
            $user_data['username'] = $user->user_login;
        }
        
        return json_encode($user_data);
    }
    
    private function create_redirect_form($redirect_url, $cart_data, $user_data) {
        $endpoint_url = rtrim($redirect_url, '/') . '/wp-admin/admin-ajax.php';
        
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Checkout</title>
        </head>
        <body>
            <form id="redirect_form" method="POST" action="<?php echo esc_url($endpoint_url); ?>">
                <input type="hidden" name="action" value="receive_external_cart" />
                <input type="hidden" name="cart_data" value="<?php echo esc_attr($cart_data); ?>" />
                <input type="hidden" name="user_data" value="<?php echo esc_attr($user_data); ?>" />
                <input type="hidden" name="redirect_token" value="<?php echo wp_create_nonce('external_cart'); ?>" />
                <input type="hidden" name="source_site" value="<?php echo esc_attr(home_url()); ?>" />
            </form>
            <script>
                // Submit immediately on page load
                document.getElementById('redirect_form').submit();
            </script>
        </body>
        </html>
        <?php
    }
}

// Initialize plugin
new CartRedirector();