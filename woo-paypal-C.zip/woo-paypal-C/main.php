<?php
/**
 * Plugin Name: Enhanced Cart Redirector
 * Description: Redirects users to external checkout with complete cart data
 * Version: 2.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class CartRedirector {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('template_redirect', array($this, 'intercept_checkout'));
        add_action('wp_ajax_nopriv_receive_order_completion', 'handle_order_completion_data');
        add_action('wp_ajax_receive_order_completion', 'handle_order_completion_data');
        add_action('wp_footer', array($this, 'handle_cart_button_redirect'));
    }
    
    public function init() {
        // Plugin initialization
    }
    
    public function admin_menu() {
        add_submenu_page(
            'woocommerce',
            'Cart Redirector Settings',
            'C Cart Redirect',
            'manage_options',
            'cart-redirector',
            array($this, 'admin_page')
        );
    }
    
   public function admin_page() {
    if (isset($_POST['submit'])) {
        $redirect_url = trim($_POST['redirect_url']);
        $product_ids_raw = trim($_POST['product_ids']);

        if (empty($redirect_url) || empty($product_ids_raw)) {
            echo '<div class="notice notice-error"><p><strong>Both Redirect URL and Product IDs are required.</strong></p></div>';
        } else {
            $product_ids_array = array_map('trim', explode(',', $product_ids_raw));
            $endpoint = rtrim($redirect_url, '/') . '/wp-json/cart-redirector/v1/validate-products';

            $response = wp_remote_post($endpoint, [
                'headers' => ['Content-Type' => 'application/json'],
                'body'    => json_encode(['product_ids' => $product_ids_array]),
                'timeout' => 10,
            ]);

            if (is_wp_error($response)) {
                echo '<div class="notice notice-error"><p>API request failed: ' . esc_html($response->get_error_message()) . '</p></div>';
            } else {
                $body = json_decode(wp_remote_retrieve_body($response), true);

                if (!empty($body['valid'])) {
                    update_option('cart_redirector_url', sanitize_url($redirect_url));
                    update_option('cart_redirector_product_ids', sanitize_text_field($product_ids_raw));
                    echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
                } else {
                    $error_message = !empty($body['error']) ? $body['error'] : 'Validation failed.';
                    if (!empty($body['missing_ids'])) {
                        $error_message .= ' Missing IDs: ' . implode(', ', $body['missing_ids']);
                    }
                    echo '<div class="notice notice-error"><p>' . esc_html($error_message) . '</p></div>';
                }
            }
        }
    }

    $redirect_url = get_option('cart_redirector_url', '');
    $product_ids = get_option('cart_redirector_product_ids', '');
?>
    <div class="wrap">
        <h1>C Redirect Settings</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th scope="row">Redirect URL</th>
                    <td>
                        <input type="url" name="redirect_url" value="<?php echo esc_attr($redirect_url); ?>" class="regular-text" required />
                        <p class="description">Enter the URL where users will be redirected (A website)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Product IDs to Send</th>
                    <td>
                        <textarea name="product_ids" class="large-text" rows="3"  required><?php echo esc_textarea($product_ids); ?></textarea>
                        <p class="description">Enter product IDs separated by commas (e.g., 123,456,789). These IDs will be sent along with cart data.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
    
    public function intercept_checkout() {
        if (is_checkout() && !is_admin() && !is_wc_endpoint_url('order-received')) {
            $redirect_url = get_option('cart_redirector_url');
            
            if (empty($redirect_url)) {
                return; // No redirect URL set
            }
            
            // Get cart data
            $cart_data = $this->get_cart_data();
            $user_data = $this->get_user_data();
            
            // Create form and auto-submit
            $this->create_redirect_form($redirect_url, $cart_data, $user_data);
            exit;
        }
    }
    
    private function get_cart_data() {
        $cart_data = array();
        
        if (WC()->cart && !WC()->cart->is_empty()) {
            foreach (WC()->cart->get_cart() as $cart_item) {
                $product = $cart_item['data'];
                $product_id = $cart_item['product_id'];
                $variation_id = $cart_item['variation_id'];
                
                // Get product image
                $image_id = $product->get_image_id();
                if (!$image_id && $variation_id) {
                    // Try to get variation image
                    $variation = wc_get_product($variation_id);
                    if ($variation) {
                        $image_id = $variation->get_image_id();
                    }
                }
                
                $image_url = '';
                if ($image_id) {
                    $image_url = wp_get_attachment_image_url($image_id, 'woocommerce_thumbnail');
                }
                
                // Get product data
                $item_data = array(
                    'product_id' => $product_id,
                    'variation_id' => $variation_id,
                    'quantity' => $cart_item['quantity'],
                    'name' => $product->get_name(),
                    'price' => $product->get_price(),
                    'discount' => WC()->cart->get_discount_total(),
                    'base_price' => get_post_meta($product_id, '_price', true),
                    'regular_price' => $product->get_regular_price(),
                    'sale_price' => $product->get_sale_price(),
                    'image_url' => $image_url,
                    'sku' => $product->get_sku(),
                    'description' => $product->get_short_description(),
                    'weight' => $product->get_weight(),
                    'dimensions' => array(
                        'length' => $product->get_length(),
                        'width' => $product->get_width(),
                        'height' => $product->get_height()
                    )
                );
                
                // Add variation data if exists
                if ($variation_id && $variation_id > 0) {
                    $variation = wc_get_product($variation_id);
                    if ($variation) {
                        $item_data['variation_data'] = array(
                            'attributes' => $variation->get_variation_attributes(),
                            'variation_description' => $variation->get_description()
                        );
                    }
                }
                
                // Add any custom product meta
               $item_data['meta_data'] = array();
                    foreach ($cart_item as $key => $value) {
                        if (
                            strpos($key, '_') !== 0 &&
                            !in_array($key, array(
                                'key', 'product_id', 'variation_id', 'quantity',
                                'data', 'data_hash', 'tmcartepo', 'tmcartfee',
                                'tmpost_data', 'tmdata', 'tmhasepo', 'addons',
                                'tm_cart_item_key', 'tm_epo_product_original_price',
                                'tm_epo_options_prices', 'tm_epo_product_price_with_options',
                                'tm_epo_options_static_prices', 'associated_products_price',
                                'tm_epo_options_total_for_cumulative', 'tm_epo_options_static_prices_first',
                                'tm_epo_set_product_price_with_options'
                            ))
                        ) {
                            $item_data['meta_data'][$key] = $value;
                        }
                    }
                    
                // Add cleaned-up TM options
                   if (!empty($cart_item['tmcartepo'])) {
                        $item_data['tm_options'] = array();
                        foreach ($cart_item['tmcartepo'] as $option) {
                            $tm_option = array(
                                'label' => !empty($option['name']) ? $option['name'] : $option['post_name'],
                                'value' => isset($option['value']) ? $option['value'] : '',
                            );
                            if (isset($option['price']) && $option['price'] !== '') {
                                $tm_option['price'] = $option['price'];
                            }
                            $item_data['tm_options'][] = $tm_option;
                        }
                    }



                
                $cart_data[] = $item_data;
            }
        }
        // Get additional product IDs from admin settings
        $additional_product_ids = array();
        $product_ids_setting = get_option('cart_redirector_product_ids', '');
        if (!empty($product_ids_setting)) {
            $product_ids_array = array_map('trim', explode(',', $product_ids_setting));
            $additional_product_ids = array_filter($product_ids_array, function($id) {
                return is_numeric($id) && $id > 0;
            });
        }
        
        return json_encode(array(
            'currency' => get_woocommerce_currency(),
            'items' => $cart_data,
            'additional_product_ids' => $additional_product_ids
        ));
    }
    
    private function get_user_data() {
        $user_data = array();
        
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            
            // Get billing and shipping info from user meta
            $billing_data = array();
            $shipping_data = array();
            
            $billing_fields = array(
                'first_name', 'last_name', 'company', 'address_1', 'address_2',
                'city', 'postcode', 'country', 'state', 'email', 'phone'
            );
            
            foreach ($billing_fields as $field) {
                $meta_key = 'billing_' . $field;
                $value = get_user_meta($user->ID, $meta_key, true);
                if (!empty($value)) {
                    $billing_data[$meta_key] = $value;
                }
            }
            
            // Use user's basic info if billing info is not available
            if (empty($billing_data['billing_first_name'])) {
                $billing_data['billing_first_name'] = $user->first_name;
            }
            if (empty($billing_data['billing_last_name'])) {
                $billing_data['billing_last_name'] = $user->last_name;
            }
            if (empty($billing_data['billing_email'])) {
                $billing_data['billing_email'] = $user->user_email;
            }
            
            // Get shipping data
            foreach ($billing_fields as $field) {
                if ($field === 'email' || $field === 'phone') continue; // Skip email/phone for shipping
                
                $meta_key = 'shipping_' . $field;
                $value = get_user_meta($user->ID, $meta_key, true);
                if (!empty($value)) {
                    $shipping_data[$meta_key] = $value;
                }
            }
            
            $user_data = array_merge($billing_data, $shipping_data);
            $user_data['user_id'] = $user->ID;
            $user_data['username'] = $user->user_login;
        }
        
        return json_encode($user_data);
    }
    
public function handle_cart_button_redirect() {
    
    $redirect_url = get_option('cart_redirector_url');
    if (empty($redirect_url)) {
        return;
    }
    
    $base_url = rtrim($redirect_url, '/');
    $f_checkout_url = $base_url . '/checkout'; 
    $actual_ajax_url = wc_get_checkout_url();
    
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const btn = document.querySelector('.checkout-button, .woocommerce-mini-cart__buttons .checkout');
        if (btn) {
            btn.setAttribute('href', '<?php echo esc_js($f_checkout_url); ?>');
              btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.location.href = '<?php echo esc_js($actual_ajax_url); ?>';
                });
        }
    });
    </script>
    <?php
}    
    
    private function create_redirect_form($redirect_url, $cart_data, $user_data) {
        // Get currency and add as URL parameter
        $currency = get_woocommerce_currency();
        $endpoint_url = rtrim($redirect_url, '/') . '/wp-admin/admin-ajax.php?currency=' . $currency;
        
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Checkout</title>
        </head>
        <body>
            <form id="redirect_form" method="POST" action="<?php echo esc_url($endpoint_url); ?>">
                <input type="hidden" name="action" value="receive_external_cart" />
                <input type="hidden" name="cart_data" value="<?php echo esc_attr($cart_data); ?>" />
                <input type="hidden" name="user_data" value="<?php echo esc_attr($user_data); ?>" />
                <input type="hidden" name="redirect_token" value="<?php echo wp_create_nonce('external_cart'); ?>" />
                <input type="hidden" name="source_site" value="<?php echo esc_attr(home_url()); ?>" />
            </form>
            <script>
                // Submit immediately on page load
                document.getElementById('redirect_form').submit();
            </script>
        </body>
        </html>
        <?php
    }
}

// Initialize plugin
new CartRedirector();


// Handle incoming order completion data
function handle_order_completion_data() {
    // Verify request
    if (!isset($_POST['order_data']) || !isset($_POST['redirect_token'])) {
        wp_die('Invalid request');
    }
    error_log('Raw order_data: ' . print_r($_POST['order_data'], true));
    
    
    // Process order data
    $order_data = json_decode(stripslashes($_POST['order_data']), true);
    error_log('Decoded order_data: ' . print_r($order_data, true));
    
    if (!empty($order_data)) {
        // Create actual order in Plugin C
        $local_order_id = create_local_order_from_external($order_data);
        
        if ($local_order_id) {
            // Empty the cart BEFORE redirecting
            if (WC()->cart) {
                WC()->cart->empty_cart();
            }
            // Redirect to the actual order's thank you page
            $order = wc_get_order($local_order_id);
            $thank_you_url = $order->get_checkout_order_received_url();
            wp_redirect($thank_you_url);
            exit;
        }
    }
    
    // Fallback if order creation failed
    wp_redirect(wc_get_checkout_url());
    exit;
}

// Create actual local order from external order data
function create_local_order_from_external($order_data) {
    // Create new order
    $order = wc_create_order();
    
    // Set customer data
    $order->set_billing_first_name($order_data['billing']['first_name']);
    $order->set_billing_last_name($order_data['billing']['last_name']);
    $order->set_billing_email($order_data['billing']['email']);
    $order->set_billing_phone($order_data['billing']['phone']);
    $order->set_billing_address_1($order_data['billing']['address_1']);
    $order->set_billing_address_2($order_data['billing']['address_2']);
    $order->set_billing_city($order_data['billing']['city']);
    $order->set_billing_state($order_data['billing']['state']);
    $order->set_billing_postcode($order_data['billing']['postcode']);
    $order->set_billing_country($order_data['billing']['country']);
    
    // Set shipping data
    $order->set_shipping_first_name($order_data['shipping']['first_name']);
    $order->set_shipping_last_name($order_data['shipping']['last_name']);
    $order->set_shipping_address_1($order_data['shipping']['address_1']);
    $order->set_shipping_address_2($order_data['shipping']['address_2']);
    $order->set_shipping_city($order_data['shipping']['city']);
    $order->set_shipping_state($order_data['shipping']['state']);
    $order->set_shipping_postcode($order_data['shipping']['postcode']);
    $order->set_shipping_country($order_data['shipping']['country']);
    
    
    // Define fields to exclude from meta
    $excluded_keys = ['image_url', 'custom_name', 'external_item_index', 'Image Url', 'Custom Name', 'External Item Index'];
    // Add order items
    foreach ($order_data['items'] as $item) {
        // Find local product by external ID or SKU
        $local_product_id = find_local_product_by_external_data($item);
        
        if ($local_product_id) {
            $product = wc_get_product($local_product_id);
            
            // Add product to order
            $order_item_id = $order->add_product($product, $item['quantity'], array(
                'subtotal' => $item['price'],
                'total' => $item['price']
            ));
            
            // Get the order item object
            $order_item = $order->get_item($order_item_id);
            
            // Add custom fields to the order item
            if (!empty($item['custom_fields']) && is_array($item['custom_fields'])) {
                foreach ($item['custom_fields'] as $field_key => $field_value) {
                    if (!empty($field_value) && !in_array($field_key, $excluded_keys)) {
                        $order_item->add_meta_data($field_key, $field_value);
                    }
                }
                $order_item->save();
            }
        } else {
            // Create a simple product entry if product not found locally
            $order_item_id = $order->add_product(null, $item['quantity'], array(
                'name' => $item['name'],
                'subtotal' => $item['price'],
                'total' => $item['price']
            ));
            $order_item = $order->get_item($order_item_id);
            
            // Still add custom fields even for non-matched products
            if (!empty($item['custom_fields']) && is_array($item['custom_fields'])) {
                foreach ($item['custom_fields'] as $field_key => $field_value) {
                    if (!empty($field_value) && !in_array($field_key, $excluded_keys)) {
                        $order_item->add_meta_data($field_key, $field_value);
                    }
                }
                $order_item->save();
            }
        }
    }
    
     // Add shipping as a fee if shipping total exists
    if (!empty($order_data['shipping_total']) && $order_data['shipping_total'] > 0) {
        $shipping_fee = new WC_Order_Item_Shipping();
        $shipping_fee->set_method_title($order_data['shipping_method']);
        $shipping_fee->set_method_id('external_shipping');
        $shipping_fee->set_total($order_data['shipping_total']);
        $order->add_item($shipping_fee);
    }
    
    // Add tax as a fee if tax total exists
    if (!empty($order_data['tax_total']) && $order_data['tax_total'] > 0) {
        $tax_fee = new WC_Order_Item_Tax();
        $tax_fee->set_rate_id(0);
        $tax_fee->set_label('Tax');
        $tax_fee->set_tax_total($order_data['tax_total']);
        $tax_fee->set_shipping_tax_total(0);
        $order->add_item($tax_fee);
        
        // Also set order tax total
        $order->set_cart_tax($order_data['tax_total']);
    }
    
    // Set order totals
    $order->set_shipping_total($order_data['shipping_total']);
    //$order->set_cart_tax($order_data['tax_total']);
    $order->set_total($order_data['total']);
    
    // Set payment method
    $order->set_payment_method($order_data['payment_method']);
    $order->set_payment_method_title($order_data['payment_method_title']);
    
    
    
    // Set created date
    $order->set_date_created(current_time('mysql'));
    
    $order->calculate_totals(false);
    // Save order
    $order_id = $order->save();
    
    if ($order_id) {
        // Store reference to external order
        update_post_meta($order_id, '_external_order_id', $order_data['order_id']);
        update_post_meta($order_id, '_external_order_key', $order_data['order_key']);
        update_post_meta($order_id, '_external_order_number', $order_data['order_number']);
        
        // Add order note
        $order->add_order_note('Order completed on external site and imported.');
        
        // Set order status to processing (since payment was completed on site A)
        $order->set_status('processing');
        $order_id = $order->save();
        
        // Trigger order processing actions
        do_action('woocommerce_new_order', $order_id, $order);
        do_action('woocommerce_order_status_processing', $order_id);
        
        

        return $order_id;
    }
    
    return false;
}

//email disable for these external orders
function disable_emails_for_external_orders($enabled, $order) {
    if ($order instanceof WC_Order) {
        if (get_post_meta($order->get_id(), '_external_order_id', true)) {
            return false; // Disable email for external orders
        }
    }
    return $enabled;
}
add_filter('woocommerce_email_enabled_new_order', 'disable_emails_for_external_orders', 10, 2);
add_filter('woocommerce_email_enabled_customer_processing_order', 'disable_emails_for_external_orders', 10, 2);


// Find local product by external data
function find_local_product_by_external_data($item) {
    
     if (!empty($item['external_variation_id']) && $item['external_variation_id'] > 0) {
        $variation = wc_get_product($item['external_variation_id']);
        if ($variation && $variation->exists() && $variation->is_type('variation')) {
            return $item['external_variation_id'];
        }
    }
    
    // First priority: use the original local product ID if available
    if (!empty($item['external_product_id'])) {
        $product = wc_get_product($item['external_product_id']);
        if ($product && $product->exists()) {
            return $item['external_product_id'];
        }
    }
    
    // Fallback: try to find by SKU
    if (!empty($item['sku'])) {
        $product_id = wc_get_product_id_by_sku($item['sku']);
        if ($product_id > 0) {
            return $product_id;
        }
    }
    
    return false;
}



